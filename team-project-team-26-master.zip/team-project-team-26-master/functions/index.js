

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//  response.send("Hello from Firebase!");
// });
const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

//exports.addTimeStamp = functions.firestore
//   .document('users/{userId}/invitations/{invitationId}')
//   .onCreate((snap, context) => {
//     if (snap) {
//       return snap.ref.update({
//                   timestamp: admin.firestore.FieldValue.serverTimestamp()
//               });
//     }
//
//     return "snap was null or empty";
//   });

//notification of acceptance
exports.sendToInvitationNotifications = functions.firestore
   .document('users/{userId}/invitations/{invitationId}')
   .onCreate((snap, context) => {
     // Get an object with the current document value.
     // If the document does not exist, it has been deleted.
     const document = snap.exists ? snap.data() : null;

     if (document) {
       var message = {
         notification: {
           title: document.name + ' sent you an invitation',
           body: 'Come join my group!',

         },
         android: {
                 notification: {
                   click_action: "tap invitation",
                 },
         },
         topic: context.params.userId
       };

       return admin.messaging().send(message)
         .then((response) => {
           // Response is a message ID string.
           console.log('Successfully sent message:', response);
           return response;
         })
         .catch((error) => {
           console.log('Error sending message:', error);
           return error;
         });
     }

     return "document was null or emtpy";
   });

// status change of pending group member
exports.sendAcceptanceGroupNotifications = functions.firestore
   .document('groups/{groupId}/users/{userId}')
   .onCreate((snap, context) => {
        // Get an object with the current document value.
        // If the document does not exist, it has been deleted.
        const document = snap.exists ? snap.data() : null;

        if (document) {
          var message = {
            notification: {
              title: document.name + ' accept your invitation',
              body: 'I joined your group!',
            },
            android:{
                notification: {
                    click_action: "teammate accept",
                },
            },
            topic: context.params.groupId
          };

          return admin.messaging().send(message)
            .then((response) => {
              // Response is a message ID string.
              console.log('Successfully sent message:', response);
              return response;
            })
            .catch((error) => {
              console.log('Error sending message:', error);
              return error;
            });
        }

        return "document was null or emtpy";
   });



//// propose a walk
exports.sendProposedWalkNotifications = functions.firestore
      .document('groups/{groupId}/ProposedWalks/{walkId}')
      .onCreate((snap, context) => {
              // Get an object with the current document value.
              // If the document does not exist, it has been deleted.
              const document = snap.exists ? snap.data() : null;

              if (document) {
                var message = {
                  notification: {
                    title: document.proposername + ' proposed a walk',
                    body: 'Come join my walk!',
                  },
                  android:{
                      notification: {
                          click_action: "proposed walk",
                      },
                  },
                  topic: context.params.groupId
                };

                return admin.messaging().send(message)
                  .then((response) => {
                    // Response is a message ID string.
                    console.log('Successfully sent message:', response);
                    return response;
                  })
                  .catch((error) => {
                    console.log('Error sending message:', error);
                    return error;
                  });
              }

              return "document was null or emtpy";
         });

//
//
//
//// status change of pending walk member
//exports.sendAcceptanceWalkNotifications = functions.firestore
//   .document('groups/groupId/')





//notification to invitee
