package edu.ucsd.cse110.WalkWalkRevolution;

public interface Invitation_interface {
    void onItemClick(int position);
}
