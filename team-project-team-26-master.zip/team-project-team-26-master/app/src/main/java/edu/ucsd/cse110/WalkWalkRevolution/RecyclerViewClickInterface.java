package edu.ucsd.cse110.WalkWalkRevolution;

// Provides interface for selection of items in LinearLayout list
interface RecyclerViewClickInterface {
    void onItemClick(int position);
}
