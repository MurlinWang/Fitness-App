package edu.ucsd.cse110.WalkWalkRevolution.service;

public class Notification {
    private String sender;
    private String content;

    public Notification(String sender, String content){
        this.sender = sender;
        this.content = content;
    }
}
