package edu.ucsd.cse110.WalkWalkRevolution;

public interface propose_interface {
    void onItemClick(int position);
}
