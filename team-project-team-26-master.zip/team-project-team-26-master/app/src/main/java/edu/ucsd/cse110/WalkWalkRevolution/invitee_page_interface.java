package edu.ucsd.cse110.WalkWalkRevolution;

public interface invitee_page_interface {
    void onItemClick(int position);
}
