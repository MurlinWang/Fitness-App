package edu.ucsd.cse110.WalkWalkRevolution;

public interface TeamRouteinterface {
    void onItemClick(int position);
}
