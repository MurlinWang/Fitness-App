package edu.ucsd.cse110.WalkWalkRevolution;

public interface TeamScreenInterface {
    void onItemClick(int position);
}
