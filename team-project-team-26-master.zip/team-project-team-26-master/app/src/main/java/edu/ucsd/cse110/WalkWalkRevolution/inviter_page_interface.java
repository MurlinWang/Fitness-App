package edu.ucsd.cse110.WalkWalkRevolution;

public interface inviter_page_interface {
    void onItemClick(int position);
}
