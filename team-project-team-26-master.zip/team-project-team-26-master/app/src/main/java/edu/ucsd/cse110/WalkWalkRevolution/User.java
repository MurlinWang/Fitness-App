package edu.ucsd.cse110.WalkWalkRevolution;

public class User {
    public String name;
    public String email;
    public String token;

    public User(String name, String email, String token){
        this.name = name;
        this.email = email;
        this.token = token;
    }

}
